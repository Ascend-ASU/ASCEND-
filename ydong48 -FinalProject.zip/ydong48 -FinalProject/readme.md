#CIS300 - Final Project Folder - Readme.md

Hi CIS300 Student!

This folder is where you will need to build your final project throughout the entire course. If you have any questions, please don't hesitate to let me know.